package com.example.equimpcontrol

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnSearch : Button = findViewById(R.id.buttonSearch)
        btnSearch.setOnClickListener {
            val editTextSearch : EditText = findViewById(R.id.editTextSearcher)
            val numberGroup = editTextSearch.text.toString()
        }
    }
}