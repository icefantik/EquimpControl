package com.example.equimpcontrol

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : Activity() {
    companion object {
        var descriptAudienc : String? = null
    }
    var numberGroup: Int? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnSearch : Button = findViewById(R.id.buttonSearch)
        btnSearch.setOnClickListener {
            val editTextSearch : EditText = findViewById(R.id.editTextSearcher)
            numberGroup = editTextSearch.text.toString().toInt()
            //Если этот номер кабинета есть в базе дынных то переходим на следующий activity
            val intent = Intent(this@MainActivity, SearchActivity::class.java)
            startActivity(intent)
        }
    }
}