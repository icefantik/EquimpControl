package com.example.equimpcontrol.database

class UserData {
    public var idUser : Int? = null
    public var login : String? = null
    public var password : String? = null
    public var fullName : String? = null
}