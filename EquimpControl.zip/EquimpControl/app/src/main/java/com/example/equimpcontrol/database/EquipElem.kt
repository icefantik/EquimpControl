package com.example.equimpcontrol.database

class EquipElem {
    public var EquipTypeId : Int? = null
    public var Name : String? = null
    public var DayOf : String? = null
    public var AudiencNum : Int? = null
}