package com.example.equimpcontrol

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.equimpcontrol.database.DBEquimpControl

class SearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_searchres)
        val db = DBEquimpControl(this)
        db.openDatabase()
        val equipString = db.getTextEquipAudienc(intent.getSerializableExtra("ExtraNumberGroup") as Int)
        setTextView(equipString)
        val button : Button = findViewById(R.id.editButton)
        button.setOnClickListener {
            val intent = Intent(this@SearchActivity, EditActivity::class.java)
            intent.putExtra("EquipString", equipString)
            startActivity(intent)
        }
        
    }
    private fun getTextView() : String
    {
        return ""
    }
    private fun setTextView(text : String)
    {
        val textView : TextView = findViewById(R.id.descriptText)
        textView.text = text
    }
}
