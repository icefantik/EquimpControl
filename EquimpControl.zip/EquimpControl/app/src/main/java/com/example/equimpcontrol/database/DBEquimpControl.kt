package com.example.equimpcontrol.database

import android.annotation.SuppressLint
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

class DBEquimpControl(var context : Context) : SQLiteOpenHelper(context, "EquipControl.db", null, 1) {
    private val DB_NAME = "EquipControl.db"
    private var DB_TABLE_EMPLOYEES = "Employees"
    private var DB_TABLE_EQUIP = "Equip"
    private var DB_TABLE_EQUIPTYPE = "EquipType"
    private var DB_TABLE_EQUIPPART = "EquipPart"
    private var DB_COLUMN = ""
    var myDataBase : SQLiteDatabase? = null

    public fun checkDataBase() : Boolean {
        var checkDB: SQLiteDatabase? = null
        try {
            val myPath =  DB_NAME
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY)
        } catch (e: SQLiteException) {
            //onCreate(myDataBase)
        }
        checkDB?.close()
        return checkDB != null
    }

    public fun openDatabase() : SQLiteDatabase?
    {
        val myPath: String = DB_NAME
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY)
        return myDataBase
    }

    @SuppressLint("Range")
    public fun checkLoginPassword(login : String, password : String, db: SQLiteDatabase?) : Boolean
    {
        val query : String = "SELECT * FROM " + DB_TABLE_EMPLOYEES
        val cursor : Cursor = db!!.rawQuery(query, null)
        while (cursor.moveToNext()) {
            if (login == cursor.getString(cursor.getColumnIndex("LOGIN")) && password == cursor.getString(cursor.getColumnIndex("PASSWORD")))
                return true
        }
        cursor.close()
        return false
    }

    @SuppressLint("Range")
    public fun checkAudiencNumber(audiencNumber : Int, db : SQLiteDatabase?) : Boolean
    {
        DB_COLUMN = "AUDIENCNUM"
        val query : String = "SELECT " + DB_COLUMN + " FROM " + DB_TABLE_EQUIP +
                " WHERE " + DB_COLUMN + " LIKE " + audiencNumber +
                " GROUP BY " + DB_COLUMN
        val cursor : Cursor = db!!.rawQuery(query, null)
        if (cursor != null && cursor.count > 0) {
            return true
        }
        return false
    }

    @SuppressLint("Range")
    public fun getTextEquipAudienc(audiencNumber : Int, db : SQLiteDatabase?) : String
    {
        var index = 0
        var equip : Array<String> = arrayOf()
        var equipStr : String = ""
        val query : String = "SELECT * FROM " + DB_TABLE_EQUIP + " WHERE AUDIENCNUM = " + audiencNumber
        val cursor : Cursor = db!!.rawQuery(query, null)
        while (cursor.moveToNext()) {
            equip[index++] = cursor.getString(cursor.getColumnIndex("NAME"))
            equipStr += cursor.getString(cursor.getColumnIndex("NAME")) + "\n"
        }
        return equipStr
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("CREATE TABLE " + DB_TABLE_EMPLOYEES + " (" +
                "ID INTEGER PRIMARY KEY, " +
                "LOGIN TEXT, " +
                "PWD TEXT, " +
                "FULLNAME TEXT" + ")")
        db?.execSQL("INSERT INTO " + DB_TABLE_EMPLOYEES +
                "(" + "ID, " + "LOGIN, " + "PWD, " + "FULLNAME" + ") VALUES " +
                "(1, \"icefantik\", \"123Qwaz\", \"Митюшин Пётр Алексеевич\"), " +
                "(2, \"Andron\", \"sdelalBDnarus0\", \"Слепов Андрей Дмитреевич\")")

        db?.execSQL("CREATE TABLE " + DB_TABLE_EQUIPTYPE + "(" +
                "ID INTEGER PRIMARY KEY, " +
                "NAME TEXT, " + ")")
        db?.execSQL("INSERT INTO " + DB_TABLE_EQUIPTYPE + "(" +
                "ID INTEGER PRIMARY KEY, " + ")" +
                " VALUES " +
                "(1, \"Комплектующие компьютера\"), " +
                "(2, \"Комплектующие принтера\")"
        )

        db?.execSQL("CREATE TABLE " + DB_TABLE_EQUIP + "(" +
                "ID INTEGER PRIMARY KEY, " +
                "EQUIPTYPEID INTEGER, " +
                "NAME TEXT, " +
                "DAYOF TEXT, " +
                "AUDIENCNUM INTEGER, " +
                "FOREIGN KEY(\"EQUIPTYPEID\") REFERENCES" + DB_TABLE_EQUIPTYPE +" (\"ID\")"+ ")")
        db?.execSQL("INSERT INTO " + DB_TABLE_EQUIP + "(" +
                "ID INTEGER PRIMARY KEY, " +
                "EQUIPTYPEID INTEGER, " +
                "NAME TEXT, " +
                "DAYOF TEXT, " +
                "AUDIENCNUM INTEGER" + ") VALUES " +
                "(1, null, \"Монитор Acer K272HLEBD\", \"01.09.2020\", 102), " +
                "(2, 1, \"intel hd690\", \"01.09.2020\", 102), " +
                "(3, 1, \"Nvidia RTX 2080\", \"01.09.2020\", 102)," +
                "(4, 2, \"Cet CET0419\", \"01.09.2020\", 105)")

        db?.execSQL("CREATE TABLE " + DB_TABLE_EQUIPPART + "(" +
                "ID INTEGER PRIMARY KEY, " +
                "EQUIPID INTEGER, " +
                "EQUIPPARTID INTEGER, " +
                "DAYOF TEXT, " +
                "NOTE TEXT" +
                "FOREIGN KEY(\"EQUIPPARTID\") REFERENCES \"Equimp\"(\"ID\"), " +
                "FOREIGN KEY(\"EQUIPID\") REFERENCES \"Equimp\"(\"ID\")" + ")")
        /*
        db?.execSQL("INSERT INTO " + DB_TABLE_EQUIPPART + "(" +
                "ID, " +
                "EQUIPID, " +
                "EQUIPTYPEID, " +
                "DAYOF, " +
                "NOTE" +
                ") VALUES " +
                "()")
         */
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

}