package com.example.equimpcontrol.database

import android.annotation.SuppressLint
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

class DBEquimpControl(var context : Context) : SQLiteOpenHelper(context, "DatabaseEquimpControl.db", null, 1) {
    private val DB_PATH = "//data//data//com.example.equimpcontrol//databases//"
    private val DB_NAME = "DatabaseEquimpControl.db"
    private var DB_TABEL = ""
    private var DB_COLUMN = ""
    var myDataBase : SQLiteDatabase? = null

    public fun checkDataBase() : Boolean {
        var checkDB: SQLiteDatabase? = null
        try {
            val myPath = DB_PATH + DB_NAME
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY)
        } catch (e: SQLiteException) {
            //база еще не существует
        }
        checkDB?.close()
        return checkDB != null
    }

    public fun openDatabase() : SQLiteDatabase?
    {
        val myPath: String =  DB_PATH + DB_NAME
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY)
        return myDataBase
    }

    @SuppressLint("Range")
    public fun checkLoginPassword(login : String, password : String, db: SQLiteDatabase?) : Boolean
    {
        DB_TABEL = "Employees"
        val query : String = "SELECT * FROM " + DB_TABEL
        val cursor : Cursor = db!!.rawQuery(query, null)
        while (cursor.moveToNext()) {
            if (login == cursor.getString(cursor.getColumnIndex("LOGIN")) && password == cursor.getString(cursor.getColumnIndex("PASSWORD")))
                return true
        }
        cursor.close()
        return false
    }

    @SuppressLint("Range")
    public fun checkAudiencNumber(audiencNumber : Int, db : SQLiteDatabase?) : Boolean
    {
        DB_TABEL = "Equimp"
        DB_COLUMN = "AUDIENCNUM"
        val query : String = "SELECT " + DB_COLUMN + " FROM " + DB_TABEL +
                " WHERE " + DB_COLUMN + " LIKE " + audiencNumber +
                " GROUP BY " + DB_COLUMN
        val cursor : Cursor = db!!.rawQuery(query, null)
        cursor.moveToNext()
        if (cursor.getInt(cursor.getColumnIndex(DB_COLUMN)) == audiencNumber) {
            return true
        }
        return false
    }

    @SuppressLint("Range")
    public fun getTextEquipAudienc(audiencNumber : Int, db : SQLiteDatabase?) : String
    {
        var index = 0
        DB_TABEL = "AudienceList"
        var equip : Array<String> = arrayOf()
        var equipStr : String = ""
        val query : String = "SELECT * FROM " + DB_TABEL + "WHERE AUDIENCNUM = " + audiencNumber
        val cursor : Cursor = db!!.rawQuery(query, null)
        while (cursor.moveToNext()) {
            equip[index++] = cursor.getString(cursor.getColumnIndex("NAME"))
            equipStr += cursor.getString(cursor.getColumnIndex("NAME")) + "\n"
        }
        return equipStr
    }

    override fun onCreate(db: SQLiteDatabase?) {
        TODO("Not yet implemented")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

}